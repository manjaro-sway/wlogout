# Credits
## Svg's
All svgs used to render icons

[Lock icon](lock.svg) from [onlinewebfonts](https://www.onlinewebfonts.com/icon/312) licensed by Creative Commons 3.0

[Logout icon](logout.svg) from [onlinewebfonts](https://www.onlinewebfonts.com/icon/248752) licensed by Creative Commons 3.0

[Suspend icon](suspend.svg) from [onlinewebfonts](https://www.onlinewebfonts.com/icon/168887) licensed by Creative Commons 3.0

[Shutdown icon](shutdown.svg) from [onlinewebfonts](https://www.onlinewebfonts.com/icon/343335) licensed by Creative Commons 3.0

[Reboot icon](reboot.svg) from [onlinewebfonts](https://www.onlinewebfonts.com/icon/249921) licensed by Creative Commons 3.0

[Hibernate icon](hibernate.svg) from [onlinewebfonts](https://www.onlinewebfonts.com/icon/20206) licensed by Creative Commons 3.0
